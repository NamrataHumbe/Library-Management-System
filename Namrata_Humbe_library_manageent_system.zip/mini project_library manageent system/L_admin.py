from book import Book
from book_mgmt import BookMgmt

def admin():
    choice = 0
    bookMgmt = BookMgmt()
    while(choice != 7):
        print("\t\t1.Add a Book")
        print("\t\t2.Search a Book")
        print("\t\t3.Delete a Book")
        print("\t\t4.Edit a Book")
        print("\t\t5.Display all Books")
        print("\t\t6.Display all Student who has issued book")
        print("\t\t7.Exit")
        choice = int(input("Enter your choice: "))
        if(choice == 1):
            bid = int(input("Enter the book id: "))
            bname = input("Enter the Book name: ")
            author = input("Enter the Book's Author name: ")
            status = int(input("Enter the Status(1/0): "))
            b1 = Book(bid,bname,author,status)
            bookMgmt.addBook(b1)
        elif(choice == 2):
            print("\ta.Search by id: ")
            print("\tb.Search by name: ")
            print("\tb.Search by author: ")
            ch = input("Enter your choice (a or b or c): ")
            if(ch.lower() == "a"):
                id =int(input("Enter the id to search: "))
                bookMgmt.searchById(id)
            elif(ch.lower() == "b"):
                name = input("Enter name to search: ")
                bookMgmt.searchByName(name)
            elif(ch.lower() == "c"):
                author = input("Enter Author name to search: ")
                bookMgmt.searchByAuthor(author)
            else:
                print("Invalid choice")
        elif(choice == 3):
            id = int(input("Enter the id you want to delete: "))
            bookMgmt.deleteById(id)
        elif(choice == 4):
            id = int(input("Enter the id you want to edit: "))
            bookMgmt.editById(id)
        elif(choice == 5):
            bookMgmt.showAllBook()
        elif(choice == 6):
            bookMgmt.showAllStudent()
        elif(choice == 7):
            print("Thank You...!")
        else:
            print("Invalid choice")
        