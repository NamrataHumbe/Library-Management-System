from student_user import student
from L_admin import admin

if(__name__ == "__main__"):
    print("\t\t1.Admin Menu")
    print("\t\t2.User Menu")
    choice = int(input("Enter your choice: "))
    if(choice == 1):
        i=0
        while(i<3):
            name = input("Enter username:")
            password = input("Enter password:")
            if (name == 'Namrata' and password == 'Namu@123'):
                print("You enter correct username n password.")
                admin()
                break
            else:
                print("You enter wrong username.\n Try again....")
                i+= 1
        else:
            print("No more trial.....")
        
    elif(choice == 2):
        student()
    
    else:
        print("Please chose correct choice...")