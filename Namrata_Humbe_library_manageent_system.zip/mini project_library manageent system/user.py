class User:
    def __init__(self,id,nm,dat):
        self.sid=id
        self.sname=nm
        self.date=dat
   
    def __str__(self):
        return str(self.sid)+","+self.sname+","+str(self.date)
