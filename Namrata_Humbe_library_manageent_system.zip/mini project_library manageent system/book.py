class Book:
    def __init__(self,id,nm,auth='unknown',stat=1):
        self.bid = id
        self.bname = nm
        self.author = auth
        self.status = stat

    def __str__(self):
        return str(self.bid)+","+self.bname+","+self.author+","+str(self.status)
