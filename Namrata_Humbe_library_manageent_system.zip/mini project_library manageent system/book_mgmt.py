from book import Book
from datetime import datetime

class BookMgmt:
    def addBook(self,b):
        with open("book.txt","a") as fp:
            fp.write(str(b)+"\n")
    
    def searchById(self,id):
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                        print("Found :",line)
                        break
                    except:
                        pass                        
                else:
                    print("Record not found")            
        except:
            print("File does not exist..")

    def searchByName(self,name):
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        (line.lower()).index(name.lower())
                        print("Found :",line)
                        break
                    except:
                        pass                        
                else:
                    print("Book not found")            
        except:
            print("File does not exist..")

    def searchByAuthor(self,author):
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        (line.lower()).index(author.lower())
                        print("Found :",line)
                        break
                    except:
                        pass                        
                else:
                    print("Book not found")            
        except:
            print("File does not exist..")    
    
    def showAllBook(self):
        try:
            with open("book.txt","r") as fp:
                print(fp.read())
            
        except:
            print("File does not exist..")

    def showAllStudent(self):
        try:
            with open("issue.txt","r") as fp:
                print(fp.read())
            
        except:
            print("File does not exist..")
        
    def deleteById(self,id):
        allBook = []
        found = False
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)                        
                    except:
                        allBook.append(line)
                    else:
                        found = True
                  
            #print(allBook)
            #If record is present, we need to overwrite the file
            if(found):
                with open("book.txt","w") as fp:
                    for book in allBook:
                        fp.write(book)
            else:
                print("Book not found")
        except:
            print("File is not Exist")
            return

    def editById(self,id):
        allBook = []
        found = False
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)                        
                    except:
                        pass
                    else:
                        found = True
                        #Edit the record
                        line = line.split(",")
                        print(line)                        
                        ans = input("Do you wish to change book name? (y/n): ")
                        if(ans.lower() == "y"):
                            line[1] = input("Enter new book name: ") 
                        ans = input("Do you wish to change Author? (y/n): ") 
                        if(ans.lower() == "y"):
                            line[2] = input("Enter new Author: ")                      
                        ans = input("Do you wish to change status? (y/n): ")
                        if(ans.lower() == "y"):
                            line[2] = input("Enter new status: ")    
                            line[2] += "\n"
                            print(line)
                        line = ",".join(line)
                    allBook.append(line)
            if(found):
                with open("book.txt","w") as fp:
                    for b in allBook:
                        fp.write(b)
            else:
                print("Book not found")
            
        except:
            print("File is not present")
            return

    def issuebook(self,user_data,bid):
        try:
            allBooks = []
            found = False
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(bid),0,4)
                        line = line.strip()
                        line = line.split(",")  
                        found = True 
                        if(int(line[3]) == 1):
                            with open("issue.txt","a") as fpp:  
                                fpp.write(str(user_data)+"\n")   
                        else:
                            print("Book is not available") 
                            return
                                            
                        line[3] = "0\n"
                        line = ",".join(line)
                    except:
                        pass
                    finally:
                        allBooks.append(line)                
                         
            if(found):
                with open("book.txt","w") as fp:
                    for book in allBooks:
                        fp.write(book)
            else:
                print("Not found")
            
        except:
            print("File not Exist")

    def submitbook(self,bid):
        allBooks = []
        found = False
        with open("book.txt","r") as fp:
            for line in fp:
                try:
                    found = True 
                    line.index(str(bid),0,4)
                    line = line.strip()
                    line = line.split(",")  
                    
                    if(int(line[3]) == 0):                           
                        line[3] = "1\n"
                        line = ",".join(line)
                except:
                    pass
                finally:
                    allBooks.append(line)                
                         
            if(found):
                with open("book.txt","w") as fp:
                    for book in allBooks:
                        fp.write(book)
            else:
                print("Not found")

    def deleteUserById(self,sid):
        allbook=[]
        found=False
        try:
            with open("issue.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(sid),0,4)
                    except:
                        allbook.append(line)
                    else:
                        found=True
            if(found):
                with open("issue.txt","w") as fp:
                    for b in allbook:
                        fp.write(b)        
            else:
                print("Book not found")
        except:
            print("File Not Exist")
            return

    def calculate_fine(self,submit_date,sid):
        with open("issue.txt","r") as fp:
            for line in fp:
                try:
                    line.index(str(sid),0,4)
                    line=line.split(",")
                    issue_date=line[2]
                    issue_date=issue_date.split("-")
                    day=int(issue_date[0])
                    month=int(issue_date[1])
                    year=int(issue_date[2])
                    issue_date=datetime(year,month,day)

                    submit_date=submit_date.split("-")
                    day=int(submit_date[0])
                    month=int(submit_date[1])
                    year=int(submit_date[2])
                    submit_date=datetime(year,month,day)
                    days=(submit_date-issue_date).days
                    if(days>10):
                        fineperday=5   #5 rs per day
                        extra=days-10
                        fine=extra*fineperday
                        print("You have taken",extra,"extra days. Please, pay fine: ",fine,"rs")
                    else:
                        print("Thank you...!")
                except:
                    print("Id not Found")
            