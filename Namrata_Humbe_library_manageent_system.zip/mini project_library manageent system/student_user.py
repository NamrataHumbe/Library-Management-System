from book import Book
from user import User
from book_mgmt import BookMgmt

def student():
    choice = 0
    userMgmt = BookMgmt()
    while(choice != 5):
        print("\t\t1.Search a Book")
        print("\t\t2.Display all Books")
        print("\t\t3.Issue Book")
        print("\t\t4.Sumbmit Book")
        print("\t\t5.Exit")
        choice = int(input("Enter your choice: "))
        if(choice == 1):
            print("\ta.Search by Name: ")
            print("\tb.Search by Author: ")
            ch = input("Enter your choice (a or b): ")
            if(ch.lower() == "a"):
                name = input("Enter name to search: ")
                userMgmt.searchByName(name)
            elif(ch.lower() == "b"):
                author = input("Enter name to search: ")
                userMgmt.searchByAuthor(author)
            else:
                print("Invalid choice")
        elif(choice == 2):
            userMgmt.showAllBook()
        elif(choice == 3):
            bid=input("Enter which book id do you wish? : ")
            sid=int(input("Enter Your id: " ))
            sname=input("Enter your name: ")
            issue_date=input("Enter date(dd-mm-yyyy): ")
            user_data = User(sid,sname,issue_date)
            userMgmt.issuebook(user_data,bid)
        elif(choice == 4):
            bid=input("Enter which book id do you submit? : ")
            sid=int(input("Enter Your id: " ))
            submit_date=input("Enter date(dd-mm-yyyy): ")
            userMgmt.submitbook(bid)
            userMgmt.calculate_fine(submit_date,sid)
            userMgmt.deleteUserById(sid)
            
        elif(choice==5):
            print("Thank You...!")
        else:
            print("Invalid choice")